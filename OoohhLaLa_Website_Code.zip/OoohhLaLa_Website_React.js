
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { MapPin, ShoppingCart, LocateFixed, Coffee, Croissant } from "lucide-react";

export default function HomePage() {
  return (
    <div className="bg-[#fffaf7] font-sans text-[#4a2e2c]">
      {/* Hero Section */}
      <section className="bg-[url('/hero-tartine.jpg')] bg-cover bg-center text-center py-24 px-4">
        <h1 className="text-5xl md:text-6xl font-bold text-[#4a2e2c] drop-shadow-md">
          Oui to Delicious!
        </h1>
        <p className="text-xl mt-4 text-[#4a2e2c]">Oui to Ooohh La La Tartine</p>
        <div className="mt-6 space-x-4">
          <Button className="bg-[#81d8d0] hover:bg-[#6fc3bc] text-[#4a2e2c] text-lg px-6 py-3">
            View Menu
          </Button>
          <Button className="bg-[#feb5b5] hover:bg-[#f89da5] text-[#4a2e2c] text-lg px-6 py-3">
            Track Our Truck
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-6 max-w-5xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-8">Our French-Inspired Story</h2>
        <p className="text-lg leading-relaxed text-center max-w-3xl mx-auto">
          Born from a love of French culture, Ooohh La La Tartine brings artisanal tartines, handcrafted drinks,
          and sweet indulgences to the streets of Miami. We're chef-owned, eco-friendly, and passionately
          committed to joy in every bite.
        </p>
      </section>
    </div>
  );
}
